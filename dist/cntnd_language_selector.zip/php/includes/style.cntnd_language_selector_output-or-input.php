<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_language_selector/css/cntnd_language_selector.css') ?>
</style>
